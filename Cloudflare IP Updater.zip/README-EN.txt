Cloudflare IP Updater
=====================
Developer: Weerapat Aphiphuwong

Program Description
-------------------
Cloudflare IP Updater is a program that automatically updates the DNS Records of your domain on Cloudflare every time your machine's IP address changes.
This ensures that your website or services remain accessible without interruption. It is suitable for home users, small organizations, or anyone who needs an automatically updated DNS system.

Key Features
------------
- Continuously monitors your current machine IP
- Automatically updates A Records on Cloudflare when the IP changes
- Supports Auto Update intervals (e.g., every 30 minutes or every hour)
- Displays update logs with total update counts
- Easy-to-use GUI interface
- Supports multiple records in the same domain, e.g., root domain and subdomains

Installation and Usage
----------------------
1. Download the Cloudflare IP Updater.exe file or ZIP, and extract if needed
2. Open the program (no installation required)
3. Enter the following information:
   - Zone Name: your domain name, e.g., example.com
   - Record Names: DNS records to update, e.g., example.com or www.example.com
   - API Token: your Cloudflare API Token (create a token with Edit Zone DNS permission)
4. Enable Auto Update and set the desired interval (optional)
5. Click the "Update" button to update the IP manually, or "Start Auto Update" for automatic updates

Creating a Cloudflare API Token
--------------------------------
1. Go to the Cloudflare Dashboard (https://dash.cloudflare.com/)
2. Navigate to My Profile → API Tokens → Create Token
3. Select Edit zone DNS
4. Specify the zone(s) to allow
5. Copy the token and enter it in the program

Notes
-----
- The program stores the API Token on your machine in an encrypted form for security
- Auto Update will stop if the program is closed, but settings will be retained for the next run
- Make sure your DNS records are configured correctly before enabling Auto Update

Limitations
-----------
- Supports only A Records
- Requires an internet connection to access the Cloudflare API
- The program must run on Windows with .NET Framework 4.7.2 or higher
